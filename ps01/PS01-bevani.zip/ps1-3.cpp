/**
 Filename: ps01.cpp
 Course: 24-780 Engineering Computation
 Created By: Balasubramanyam Evani
 andrewId: bevani
 Date: 9/5/23.
 
 The following code gives a brief introduction about myself
 in order to fulfill the requirements of the first problem set for this
 course.
 */

#include <iostream>


int main(void) {
    std::cout << "My name is Balasubramanyam Evani" << std::endl;
    std::cout << "I'm a second year MSc ECE student here at CMU" << std::endl;
    std::cout << "I first learned programming almost 7 years ago." << std::endl;
    std::cout << "My hobbies are playing badminton, guitar" << std::endl;
    std::cout << "watching anime, working on some private deep learning projects" << std::endl;
    std::cout << "travelling, and hiking" << std::endl;
    return 0;
}
